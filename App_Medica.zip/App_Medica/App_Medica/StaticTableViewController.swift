//
//  StaticTableViewController.swift
//  App_Medica
//
//  Created by alumno on 20/10/16.
//  Copyright © 2016 815968. All rights reserved.
//

import UIKit

protocol ProtocolAgregarMedicinas {
	func agregarMedicina(nombre:String,CantidadCaja:Int,CantidadToma:Int,TipoAdimnistracion:String,HoraInicio:NSDate,intervalo:TimeInterval,image:UIImage,comentarios:String) -> Void
	func quitarVista() -> Void
}
class StaticTableViewController: UITableViewController {
	
	var nombre:String!
	var CantidadCaja:Int!
	var CantidadToma:Int!
	var TipoAdimnistracion:String!
	var HoraInicio:NSDate!
	var intervalo:TimeInterval!
	var image:UIImage!
	var comentarios:String!
	
	var delegado:ProtocolAgregarMedicinas!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "Agregar"
		let barButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(done))
		self.navigationItem.rightBarButtonItem = barButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

	func done(){
		delegado.agregarMedicina(nombre: nombre, CantidadCaja: CantidadCaja, CantidadToma: CantidadToma, TipoAdimnistracion: TipoAdimnistracion, HoraInicio: HoraInicio, intervalo: intervalo, image: image, comentarios: comentarios)
	}
	
    // MARK: - Navigation

	
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		
    }
	

}
