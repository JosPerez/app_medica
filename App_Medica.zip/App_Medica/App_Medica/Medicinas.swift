//
//  Medicinas.swift
//  App_Medica
//
//  Created by alumno on 20/10/16.
//  Copyright © 2016 815968. All rights reserved.
//

import UIKit

class Medicinas: NSObject {

	
	var nombre:String!
	var CantidadCaja:Int!
	var CantidadToma:Int!
	var TipoAdimnistracion:String!
	var HoraInicio:NSDate!
	var intervalo:TimeInterval!
	var image:UIImage!
	var comentarios:String!
	
	init(nombre:String,CantidadCaja:Int,CantidadToma:Int,TipoAdimnistracion:String,HoraInicio:NSDate,intervalo:TimeInterval,image:UIImage,comentarios:String){
		self.nombre = nombre
		self.CantidadCaja = CantidadCaja
		self.CantidadToma = CantidadToma
		self.TipoAdimnistracion = TipoAdimnistracion
		self.HoraInicio = HoraInicio
		self.intervalo = intervalo
		self.image = image
		self.comentarios = comentarios
	}
	override init() {
		self.nombre = nil
		self.CantidadCaja = nil
		self.CantidadToma = nil
		self.TipoAdimnistracion = nil
		self.HoraInicio = nil
		self.intervalo = nil
		self.image = nil
		self.comentarios = nil
	}
	
}
