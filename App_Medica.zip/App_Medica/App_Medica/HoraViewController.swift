//
//  HoraViewController.swift
//  App_Medica
//
//  Created by alumno on 20/10/16.
//  Copyright © 2016 815968. All rights reserved.
//

import UIKit

class HoraViewController: UIViewController {

	var HoraInicio:NSDate!
	var intervalo:TimeInterval!
	
	//Texfield con DatePicker
	@IBOutlet weak var tfInicio: UITextField!
	@IBAction func tfHoraInicio(_ sender: UITextField) {
		let datePickerView = UIDatePicker()
		datePickerView.datePickerMode = .time
		sender.inputView = datePickerView
		datePickerView.addTarget(self, action: #selector(datepickerValueChange), for: .valueChanged)
	}
	@IBOutlet weak var tfMuestraIntervalo: UITextField!
	@IBAction func tfIntervalo(_ sender: UITextField) {
		let datePickerView = UIDatePicker()
		datePickerView.datePickerMode = .countDownTimer
		sender.inputView = datePickerView
		datePickerView.addTarget(self, action: #selector(datepickerValue), for: .valueChanged)
	}
	@IBAction func Guardar(_ sender: UIButton) {
		navigationController?.popViewController(animated: true)
	}
	
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
	func quitarTeclado() {
		view.endEditing(true)
	}
	override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
		quitarTeclado()
	}
	//MARK: - Metodos de Date picker
	func datepickerValueChange(_sender:UIDatePicker){
		let Formatter = DateFormatter()
		Formatter.dateStyle = .short
		Formatter.timeStyle = .short
		HoraInicio = _sender.date as NSDate!
		tfInicio.text = Formatter.string(from: _sender.date)
	}
	
	func datepickerValue(_sender:UIDatePicker){
		let Formatter = DateFormatter()
		Formatter.dateStyle = .short
		Formatter.timeStyle = .short
		intervalo = _sender.countDownDuration
		let hora = Int(_sender.countDownDuration/3600)
		let min = Int((_sender.countDownDuration.truncatingRemainder(dividingBy:3600 ))/60)
		if(hora == 1){
			if(min == 1) {
				tfMuestraIntervalo.text = "\(hora) hora, \(min) minuto"
			}else {
				tfMuestraIntervalo.text = "\(hora) hora, \(min) minutos"
			}
		}else {
			if(min == 1) {
				tfMuestraIntervalo.text = "\(hora) horas, \(min) minuto"
			}else {
				tfMuestraIntervalo.text = "\(hora) horas, \(min) minutos"
			}
		}
	}
	
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		
		let StaticView = segue.destination as! StaticTableViewController
		
		StaticView.HoraInicio = HoraInicio
		StaticView.intervalo = intervalo
    }
	

}
