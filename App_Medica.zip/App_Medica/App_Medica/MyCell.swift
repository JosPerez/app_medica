//
//  MyCell.swift
//  App_Medica
//
//  Created by alumno on 20/10/16.
//  Copyright © 2016 815968. All rights reserved.
//

import UIKit

class MyCell: UITableViewCell {

	@IBOutlet weak var imimage: UIImageView!
	@IBOutlet weak var lbNombre: UILabel!
	@IBOutlet weak var lbHoratoma: UILabel!
	@IBOutlet weak var lbCantidadRest: UILabel!
	

}
