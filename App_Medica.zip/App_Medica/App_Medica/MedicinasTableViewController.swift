//
//  MedicinasTableViewController.swift
//  App_Medica
//
//  Created by alumno on 20/10/16.
//  Copyright © 2016 815968. All rights reserved.
//

import UIKit

class MedicinasTableViewController: UITableViewController,ProtocolAgregarMedicinas {

	var medicina = [Medicinas]()
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return medicina.count
    }

	
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! MyCell
		
		cell.imimage.image = medicina[indexPath.row].image
		cell.lbCantidadRest.text = "\(medicina[indexPath.row].CantidadCaja)"
		
		

        

        return cell
    }


	
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
	func agregarMedicina(nombre:String,CantidadCaja:Int,CantidadToma:Int,TipoAdimnistracion:String,HoraInicio:NSDate,intervalo:TimeInterval,image:UIImage,comentarios:String){
		let medic = Medicinas.init(nombre: nombre, CantidadCaja: CantidadCaja, CantidadToma: CantidadToma, TipoAdimnistracion: TipoAdimnistracion, HoraInicio: HoraInicio, intervalo: intervalo, image: image, comentarios: comentarios)
		
		medicina.append(medic)
	}
	func quitarVista(){
		navigationController?.popViewController(animated: true)
	}
}
